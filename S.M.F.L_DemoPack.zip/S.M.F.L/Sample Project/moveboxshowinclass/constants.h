#ifndef CONSTANTS_H
#define CONSTANTS_H


const int SCREEN_WIDTH = 1000;
const int SCREEN_HEIGHT = 600;

#endif // CONSTANTS_H
