#include <iostream>
#include "game.h"
using namespace std;

int main()
{
    Game mygame;
    mygame.run();
    return 0;
}
