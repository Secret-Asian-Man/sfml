#include "game.h"
#include "constants.h"
#include <iostream>
using namespace std;

Game::Game(){
    window.create(sf::VideoMode(SCREEN_WIDTH, SCREEN_HEIGHT), "Wenyuan's Sample Window!");
    //VideoMode class has functions to detect screen size etc.
    //RenderWindow constructor has a third argumnet to set style
    //of the window: resize, fullscreen etc.

    window.setFramerateLimit(60);

    mybox.setFillColor(sf::Color::Red);
    mybox.setSize(sf::Vector2f(20,30));
    mybox.setPosition(0,0);
}

void Game::Draw(){
    //Look at the data and based on the data, draw shapes on window object.
    window.draw(mybox);
}


void Game::update()
{
    if((mybox.getPosition().y + mybox.getSize().y < SCREEN_HEIGHT)&&(mybox.getPosition().x + mybox.getSize().x < SCREEN_WIDTH))
    {
        mybox.move(0.5,1);
    }
    else {
        if (mybox.getPosition().y + mybox.getSize().y >= SCREEN_HEIGHT){
            mybox.setPosition(mybox.getPosition().x,0);
        }
        else {
            mybox.setPosition(0,mybox.getPosition().y);
        }
    }
}
void Game::render(){
       window.clear();
       Draw();
       window.display();
}



void Game::processEvents()
{
   sf::Event event;
   while (window.pollEvent(event))//or waitEvent
       {
       // check the type of the event...
           switch (event.type)
           {
               // window closed
               // "close requested" event: we close the window
               case sf::Event::Closed:
                   window.close();
                   break;

               // key pressed
               case sf::Event::KeyPressed:
                   //...
                   break;
               case sf::Event::MouseButtonReleased:
                       if (event.mouseButton.button == sf::Mouse::Right)
                       {
                           std::cout << "the right button was pressed" << std::endl;
                           std::cout << "mouse x: " << event.mouseButton.x << std::endl;
                           std::cout << "mouse y: " << event.mouseButton.y << std::endl;
                       }
                       else
                           std::cout<<"left button?"<<std::endl;
                           mybox.setPosition(event.mouseButton.x,event.mouseButton.y);

                       break;

                   default:
                       break;
           }
       }
}
void Game::run()
{
   while (window.isOpen())
   {
       processEvents();
       update();
       render(); //clear/draw/display
   }
}
